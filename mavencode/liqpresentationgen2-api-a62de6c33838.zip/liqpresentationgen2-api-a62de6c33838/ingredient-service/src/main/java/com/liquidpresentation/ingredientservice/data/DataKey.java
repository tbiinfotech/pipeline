package com.liquidpresentation.ingredientservice.data;

public enum DataKey {
	NEWPRICE,
	UPDATEPRICE,
	DELETEPRICE,
	BADPRICE,
	NEWINGREDIENT,
	NEWBRAND
}
